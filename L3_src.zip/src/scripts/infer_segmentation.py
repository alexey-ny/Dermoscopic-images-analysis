import os
import SimpleITK as sitk
import numpy as np
import pandas as pd
from scripts.unet import get_unet_2D
from scripts.image_processing.image_window import get_image_path_by_id, remove_arm_area
from scripts.image_processing.get_sitk_from_array import write_sitk_from_array_by_template
from scripts.image_processing.slice_area_density import get_l3_slice_area, get_l3_slice_density


def test(image_dir, model_weight_path, csv_output_path, output_dir):
    """
    AK
    Inference of the pretrained segmentation UNet model. Will save segmentations
    as NIFTI files and computed Body Composition indices into a csv file.

    Parameters
    ----------
    image_dir : str
        Dir path of abdominal CT scan files.
    model_weight_path : str
        File path to the pretrained model weights.
    csv_output_path : str
        Path to a csv file with preselected L3 slice numbers of the input CT scans.
        Also where the final L3 slice body composition metrics will be saved.
    output_dir : str
        Dir path to segementation results in NIFTI format.

    Returns
    -------
    None.

    """
    
    model = get_unet_2D(4, (512, 512, 1), num_convs=2, activation='relu',
            compression_channels = [16, 32, 64, 128, 256, 512],
            decompression_channels = [256, 128, 64, 32, 16]   )
    model.load_weights(model_weight_path)
    # AK create a dataframe for Body Composition indiuces to be saved in a csv file
    df_BC = pd.DataFrame(columns = ['patient_id', 'muscle_manual_area', 'muscle_manual_density', 'sfat_manual_area',
                                      'sfat_manual_density', 'vfat_manual_area', 'vfat_manual_density'])
    
    # AK load the dataframe of preselected L3 slices
    df_prediction_l3 = pd.read_csv(csv_output_path, index_col=0)
    # AK iterate over the dataframe with L3 slices
    for pred_slice in df_prediction_l3.itertuples(index=False):

        patient_id = str(pred_slice.patient_id)
        l3_slice_auto = int(pred_slice.L3_Predict_slice)

        infer_3d_path = output_dir + patient_id + '_AI_seg_L3.nii.gz'
        image_path = get_image_path_by_id(patient_id, image_dir)
        image_sitk =  sitk.ReadImage(image_path)
        image_array_3d  = sitk.GetArrayFromImage(image_sitk)

        # AK reshape so it is a batch of 1 images with 1 channel
        image_array  = sitk.GetArrayFromImage(image_sitk)[l3_slice_auto,:,:].reshape(1, 512, 512, 1) 
        image_array_2d  = sitk.GetArrayFromImage(image_sitk)[l3_slice_auto,:,:]

        target_area = remove_arm_area(image_array_2d)
        infer_seg_array = model.predict(image_array)

        # AK defining segmentation masks
        softmax_threshold = 0.5
        muscle_seg = (infer_seg_array[:,:,:,1] >= softmax_threshold) * 1.0 * target_area
        sfat_seg = (infer_seg_array[:,:,:,2] >= softmax_threshold) * 2.0 * target_area
        vfat_seg = (infer_seg_array[:,:,:,3] >= softmax_threshold) * 3.0 * target_area
        infer_seg_array_2d = muscle_seg + sfat_seg + vfat_seg
        infer_seg_array_3d = np.zeros(image_array_3d.shape)
        infer_seg_array_3d[l3_slice_auto,:,:] = infer_seg_array_2d

        write_sitk_from_array_by_template(infer_seg_array_3d, image_sitk, infer_3d_path )
        print(f'l3_slice_auto: {l3_slice_auto}, segmentation in NIFTI saved into the file - {infer_3d_path}')

        if os.path.exists(image_path) and os.path.exists(infer_3d_path):
            print('Calculating BC metrics  \n')  
            muscle_auto_area, sfat_auto_area, vfat_auto_area = \
                                get_l3_slice_area(patient_id, l3_slice_auto, output_dir)  
            muscle_auto_density, sfat_auto_density, vfat_auto_density = \
                                get_l3_slice_density(patient_id, l3_slice_auto, output_dir, image_dir)
            round_num = 2      
            # AK add a new record to the Body Composition dataframe
            df_BC.loc[df_BC.shape[0]] = [patient_id, 
                                         round(muscle_auto_area, round_num), round(muscle_auto_density, round_num),
                                         round(sfat_auto_area, round_num), round(sfat_auto_density, round_num),
                                         round(vfat_auto_area, round_num), round(vfat_auto_density, round_num)]

    df_BC.to_csv(csv_output_path)
    print(f'The Body Composition indices are written to the file {csv_output_path}')
