# -*- coding: utf-8 -*-
"""
Created on Fri Mar 24 12:51:08 2023

@author: alex
"""
import os, glob
import pandas as pd

from scripts.image_processing.image_window import get_image_path_by_id,apply_window
from scripts.image_processing.slice_area_density import get_l3_slice_area,get_l3_slice_density
import SimpleITK as sitk
import numpy as np


image_dir = '../data/test/input'

img_names = os.listdir(image_dir)
images = [os.path.join(image_dir, x) for x in img_names]
images2 = [(image_dir + '/'+ x) for x in img_names]

images1 = sorted(glob.glob(os.path.join(image_dir, '*.nii*')))

image_dir = '../data/test/input'

img_names = os.listdir(image_dir)
images = [(image_dir + '/'+ x) for x in img_names]

print(len(images), images[0])


csv_path = '../data/test/output_csv/L3_Top_Slice_Prediction.csv'
df_l3_prediction = pd.read_csv(csv_path, index_col = 0)

print(df_l3_prediction.shape)
(df_l3_prediction.head())

img_dir  = '../data/test/input/'
seg_dir = '../data/test/output_segmentation/'
csv_write_path = '../data/test/output_csv/L3_body_comp_area_density.csv'
print('img_dir: ',img_dir)
print('seg_dir: ',seg_dir)

df_BC = pd.DataFrame(columns = ['patient_id', 'muscle_manual_area', 'muscle_manual_density', 'sfat_manual_area',
                                  'sfat_manual_density', 'vfat_manual_area', 'vfat_manual_density'])
for idx, row in df_l3_prediction.iterrows():
    patient_id =  row['patient_id']
    image_path =  get_image_path_by_id(patient_id, img_dir)
    seg_path = get_image_path_by_id(patient_id, seg_dir)
    # print('patient_id: ',patient_id)
    # print('image_path: ',image_path)
    # print('seg_path: ',seg_path)
    
    if os.path.exists(image_path) and os.path.exists(seg_path):
        l3_slice = int(row['L3_Predict_slice'])

        muscle_auto_area,sfat_auto_area,vfat_auto_area = \
                            get_l3_slice_area(patient_id,l3_slice,seg_dir)  

        muscle_auto_density,sfat_auto_density,vfat_auto_density = \
                            get_l3_slice_density(patient_id,l3_slice,seg_dir,img_dir)

        round_num = 2      
        df_BC.loc[df_BC.shape[0]] = [patient_id, round(muscle_auto_area, round_num), 
                                     round(muscle_auto_density, round_num),
                                     round(sfat_auto_area, round_num), round(sfat_auto_density, round_num),
                                     round(vfat_auto_area, round_num), round(vfat_auto_density, round_num)]
        
        print(f'{idx}th patient: ', patient_id)
        # print(idx,'th', patient_id, 'writen to', csv_write_path)
        print()
        
    print(f'The BC info is written to the file {csv_write_path}')
    df_BC.to_csv(csv_write_path)
