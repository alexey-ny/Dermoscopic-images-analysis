import argparse
import os
import warnings
from scripts.infer_segmentation import test
os.environ["TF_CPP_MIN_LOG_LEVEL"] = '3'
warnings.filterwarnings("ignore")
   
if __name__ == '__main__':

    parser = argparse.ArgumentParser(description='Bodycomposition is segmented and stored in NIFTI format.') 
    
    parser.add_argument('--image_dir','-i', type = str, default = '../data/test/input', 
                        help = 'File path of abdominal CT scan')
    
    parser.add_argument('--model_weight_path','-m', type = str, default = '../model/test/L3_Top_Segmentation_Model_Weight.hdf5',
                        help = 'File path of well-trained model weight')
    # AK changed name of the parameter, as we save multiple csv files there, not just L3 slice selection
    parser.add_argument('--csv_output_path','-c', type = str, default = '../data/test/output_csv/L3_Top_Slice_Prediction.csv',
                        help = 'L3 top slice number of the input CT scan')
    
    parser.add_argument('--output_dir','-o', type = str, 
                        default = '../data/test/output_segmentation/',
                        help = 'File path of well-trained model weight')    

    args = parser.parse_args()
    # print(args)
    model = test(**vars(args))
    
# model = test(image_dir='../data/test/input', model_weight_path='../model/test/L3_Top_Segmentation_Model_Weight.hdf5', l3_slice_csv_path='../data/test/output_csv/L3_Top_Slice_Prediction.csv', output_dir='../data/test/output_segmentation/')
# image_dir='../data/test/input'
# model_weight_path='../model/test/L3_Top_Segmentation_Model_Weight.hdf5'
# l3_slice_csv_path='../data/test/output_csv/L3_Top_Slice_Prediction.csv'
# output_dir='../data/test/output_segmentation/'
# csv_write_path = '../data/test/output_csv/L3_body_comp_area_density.csv'
